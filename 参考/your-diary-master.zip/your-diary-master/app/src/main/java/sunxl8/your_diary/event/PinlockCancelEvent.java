package sunxl8.your_diary.event;

/**
 * Created by hahaha on 2017/2/22.
 */

public class PinlockCancelEvent {
}
