package sunxl8.your_diary.event;

/**
 * Description: <br>
 * author: sun<br>
 * date: 2017/2/12.<br>
 * Email：xiaoleisun92@gmail.com
 */

public class MainRefreshEvent {
}
