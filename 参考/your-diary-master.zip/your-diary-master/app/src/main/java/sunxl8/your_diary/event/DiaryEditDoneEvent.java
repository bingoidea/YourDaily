package sunxl8.your_diary.event;

/**
 * Created by sunxl8 on 2017/2/14.
 */

public class DiaryEditDoneEvent {
}
